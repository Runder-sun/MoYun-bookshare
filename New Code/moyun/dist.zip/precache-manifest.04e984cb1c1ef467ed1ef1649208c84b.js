self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0960b5e514adcb715a23",
    "url": "/css/app.473c66c4.css"
  },
  {
    "revision": "e8904921a8037424e254",
    "url": "/css/chunk-vendors.d86e0390.css"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "/img/logo.82b9c7a5.png"
  },
  {
    "revision": "ee0b26d6e3420fe66a28e9bbb63a23f5",
    "url": "/img/widthPic.ee0b26d6.jpg"
  },
  {
    "revision": "b38fc24d75b088ce159c1085828f949f",
    "url": "/index.html"
  },
  {
    "revision": "0960b5e514adcb715a23",
    "url": "/js/app.d0689601.js"
  },
  {
    "revision": "e8904921a8037424e254",
    "url": "/js/chunk-vendors.40c7c0f4.js"
  },
  {
    "revision": "09b385b3a5a031a06d32e804313045e7",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);